 export const getData = async () => {
    const res = await fetch("https://type.fit/api/quotes");
    const data = await res.json();
    return data;
    
};

